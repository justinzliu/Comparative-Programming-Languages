package exer8

// TODO: The Point struct, NewPoint function, .String and .Norm methods