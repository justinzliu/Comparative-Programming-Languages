package exer9

// TODO: Point (with everything from exercise 8 and) and methods that modify them in-place
