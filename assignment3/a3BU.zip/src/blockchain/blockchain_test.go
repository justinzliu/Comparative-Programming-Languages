package blockchain

import (
	"fmt"
	"github.com/stretchr/testify/assert"
	"testing"
)

// TODO: some useful tests of Blocks
func TestQueueBasics(t *testing.T) {
	//valid chain test
	b0 := Initial(20)
	b0.Mine(10)
	//fmt.Println(b0.Proof, hex.EncodeToString(b0.Hash))
	b1 := b0.Next("this is an interesting message")
	b1.Mine(10)
	//fmt.Println(b1.Proof, hex.EncodeToString(b1.Hash))
	b2 := b1.Next("this is not interesting")
	b2.Mine(10)
	//fmt.Println(b2.Proof, hex.EncodeToString(b2.Hash))
	b3 := b2.Next("this is kinda interesting")
	b3.Mine(10)
	//fmt.Println(b3.Proof, hex.EncodeToString(b3.Hash))
	bChain := Blockchain{}
	bChain.Add(b0)
	bChain.Add(b1)
	bChain.Add(b2)
	bChain.Add(b3) 
	if(bChain.IsValid()){fmt.Println("test1: bChain is valid, pass")}
	//invalidate a block
	bChain.Chain[2].Difficulty = 1
	if(!bChain.IsValid()){fmt.Println("test2: bChain is invalid, pass")}
	bChain.Chain[2].Difficulty = 20 //reset chain
	if(bChain.IsValid()){fmt.Println("chain successfully reset")}
	badBlock := b2
	bChain.Chain = append(bChain.Chain, badBlock)
	if(!bChain.IsValid()){fmt.Println("test3: bChain is invalid, pass")}
}